$(function(){
	//回到顶部
	$(".news_TOP").click(function(){
			$('body,html').animate({scrollTop:0},300); 
	})
});