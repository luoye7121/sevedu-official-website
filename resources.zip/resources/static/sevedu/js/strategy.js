$(function(){
	//页面高度
	$(".index-content").height($(document.body).outerHeight(true));
	$("body").height($(document.body).outerHeight(true));
	$(".strategy-title").eq(0).animate({
		"left":"440px"},
		2000, function() {
		/* stuff to do after animation is complete */
		$(".strategy-substance").eq(0).fadeIn();
	});
})